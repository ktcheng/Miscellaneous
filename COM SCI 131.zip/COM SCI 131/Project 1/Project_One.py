# Celsius to Fahrenheit Temperature Converter

c = input("Enter a Celsius temperature: ")
f = (9 / 5) * (float(c)) + 32 
print("The fahrenheit equivalent is: " + str(f))
